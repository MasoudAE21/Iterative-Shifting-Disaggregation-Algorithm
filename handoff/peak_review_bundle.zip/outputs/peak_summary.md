# Modeled population daily peak



Target: 2025-01-20 through 2025-03-20, inclusive; Asia/Tehran civil days.

Selected date: **2025-02-10**. Units: **source_units_unknown per day**, preserving original bill totals without conversion.

Input: 362,660 distinct customers, 513,921 bills. Selected output: 362,660 customers; accepted/fully reconciled bills: 513,921.

Fixed peak-selection population: 143,859 fully covered customers. Source coverage: {'full': 143859, 'partial': 218564, 'none': 237}. This is a modeled population peak, not a full-city peak.

Peak total: 2183460.535366701. Exported population sum: 2183460.535366701.



## Highest five daily totals



- 2025-02-10: 2183460.535366701

- 2025-02-25: 2112922.7718999404

- 2025-02-11: 2080322.8789625876

- 2025-02-09: 2021471.967862353

- 2025-02-26: 1952741.5290295726



Missing output values: 47,309; reasons: {'no_target_bill': 47309}. Customer-level reasons are in peak_missing_reasons.csv. Available: 315,351; retained zeros: 12,927.

Fixed full-target valid-billing population; exact ties choose earliest date. All output customers use that same date.

Shortest round-trip float64 decimal (Python repr); no fixed decimal rounding. Compensated float64 totals select the peak before export.



## Verification and review

Full-bill reconciliation passed: 513,921; maximum absolute discrepancy: 3.637978807091713e-12. Full/target identities passed: True. CSV identity, unique row, finite nonnegative value and round-trip reconciliation checks passed: True.

Review F1: narrowly classified availability fallback; operational/checkpoint/configuration errors propagate. F2: advancing bill cursor replaces retained customer DataFrames. F3: reject blank/whitespace and multiline physical CSV records before normalization. See handoff/peak_review_resolutions.md and verification artifacts.

Optional O1–O3 are deferred: the current target remains 1403, metadata remains provisional and RSS measurement is available locally.

No measured daily accuracy is claimed. Existing cohort ISD, exposure adaptation, uniform full-bill fallback and missing-value policies remain unchanged. Physical units, billing semantics, weather representativeness and customer daily accuracy remain unconfirmed. No hourly conversion, external data or city scaling was applied.



## Runtime and reproducibility

Wall seconds: 218.387142; peak process RSS bytes: 1,507,880,960.

Stage times: {'import_audit_seconds': 3.7546922999972594, 'population_seconds': 4.190072299999883, 'weather_seconds': 0.021559100001468323, 'model_seconds': 39.27521020000131, 'export_seconds': 146.94563760000165, 'peak_export_seconds': 22.078694700001506}

Run from the IDE with run_pipeline.py; defaults select all available input customers. production=False retains the provisional semantic gates.

Configuration and hashes (SHA256):

```json

{
  "configuration": {
    "mode": "provisional_cohort_isd",
    "engine": "scaled",
    "alpha": 0.05,
    "n_lr_models": 10,
    "n_disagg_cycles": 10,
    "target_start": "2025-01-20",
    "target_end_exclusive": "2025-03-21",
    "timezone": "Asia/Tehran",
    "feature_preset": "winter_hdd65_v1",
    "endpoint_convention": "inclusive",
    "endpoint_confirmed": false,
    "calendar_origin_confirmed": false,
    "day_basis_confirmed": false,
    "target_year_confirmed": false,
    "target_jalali_year_candidate": 1403,
    "physical_zero_confirmed": false,
    "export_unmodified_confirmed": false,
    "consumption_unit": "source_units_unknown",
    "provider_variable_definition": "instant",
    "weather_adapter": "point_linear_integral_v1",
    "ordering_version": "customer_start_end_bill_id_v1",
    "coverage_policy": "balanced_cohort_uniform_elsewhere_v1",
    "zero_residual_policy": "keep_current",
    "residual_tolerance_policy": "64eps_length_max_scale_v1",
    "reconciliation_atol": 1e-08,
    "reconciliation_rtol": 1e-10,
    "regression_rcond": null,
    "exposure_scaled": true,
    "production": false,
    "max_customers": null,
    "sample_scope": "universe",
    "sample_seed": "isd_pilot_v1:",
    "row_group_size": 100000,
    "ingestion_chunk_size": 100000,
    "memmap_threshold_mb": 256,
    "checkpoint": true,
    "resume": false
  },
  "inputs": {
    "bill_1403.csv": "a40d065cf7bf0168c34443912318ad5f51e07b8af99a77c351191cbbe828f29d",
    "open-meteo-34.41N50.49E1435m.csv": "6c56d838b470e1255332b1ec0e39c48280bbfe27e0c7b0d8df65582cc1894533",
    "ISD_Independent_Review.docx": "d811fd7bc5f7118436c2a9e703c16c13dc651fad7f7c97b5ab8f7ef957f839d1",
    "ISD_Implementation_Handoff.docx": "5e5c94fe9493aca26b766b16346f361a8cc03cd479ff336331afce70d990e400",
    "An Iterative Shifting Disaggregation Algorithm .pdf": "da4804937e984877a257dee8b4affefa9670989d351d236bbdcd253b011792d5"
  },
  "source": {
    "source_sha256": "f97a02412ae7e5a8522256a8e5974cfbc4747c221f2bcf15f8e77c92669eed04",
    "files": {
      "run_pipeline.py": "528bb55195d742d0d3cbdc383d0e0dc01684f84c272515b4354c5371ed3ec7e4",
      "requirements.txt": "2ae5e6e68306bce976cad4100e0745819265b117f9f43afbaa49ee6dd5fa6536",
      "README.md": "85c84c4c55b7839820bf60c9dbd454a590eac22c24ff0be556ec404d01b442ad",
      "isd\\__init__.py": "a3dc635c8d567aa016e03fe258ed08a5cee107f9022e91c99418e775f9d00abe",
      "isd\\config.py": "3046c31027596860799e7044aa6951e15a450174c898d6ffa358a7bb08ad6247",
      "isd\\data.py": "84a41a6ad3042fc04445afa38f762f3898e1884644ad16fad660da5326398a0c",
      "isd\\data_reference.py": "802c2797ce5ec11427423b648cf74e92e7f5d4a0c78e996b251a7355ab672391",
      "isd\\errors.py": "6c25b23b62068c6f64bdd671ec2176feeab1ae5f295f108a5fc767cbbda5366f",
      "isd\\experiments.py": "e152922b446e17300201a5779b866ae831c74cda3d5cea5051e4f6fad36d12a5",
      "isd\\peak.py": "0ba9bb5157aa7f21cce358a59f648b7e1f484dbedc477e3d3b5d6aa06c9a233c",
      "isd\\pipeline.py": "41f49e9729c5ac69c68a5f09729b1af58a3170d9a8d64a9f7eebdc81c72934d9",
      "isd\\solver.py": "c2ac168872f1723fffe265777a3edb428547df0538d31871fce558ccfeae1a66",
      "isd\\weather.py": "6054c26f5986c35f37be5ad31568901d2ef9454e5e0b9017857898ace7701d44",
      "tests\\test_data_weather.py": "fdf297909855fc082202d62c738f2ea965053c840a585d208562f28827354bb7",
      "tests\\test_peak_review.py": "9a83a5372277f98c4a5d2ca77fdbfeee3558d4981d01a32f9bc5f366b5758c5c",
      "tests\\test_pipeline.py": "e039c1aac849c928f5027412c9cda657019396a4424db2d5175b6babd7ea61cd",
      "tests\\test_real_fixture.py": "90466e6da9987d8e516b2ce0c12ac8b53b0f68b967b0dc1583a3eb19478ac1b1",
      "tests\\test_solver.py": "a7be0ecd5e978971533f4a30f478184411689b3507f5089ba1487af364be6cda",
      "configs\\boundary_unscaled_sensitivity.json": "89c9ac9eb36810e2dde2d1945370ce50b3b8e0462d6d1ecb7faaed2e0fdcc8eb",
      "configs\\cohort_pilot.json": "f7195c952a07491ce73017bb73dad468466c61e22ddb6b156871efab5916f825",
      "configs\\paper_reference.json": "4ad82d999605e91ec9a804971888babf01de9e3e5a79cbc6dc975ea8c7d6e416",
      "configs\\peak.json": "ee246198911a764469f075dd0c32e3c689884bea363d325abb83ca82608c7bc0",
      "configs\\pilot.json": "6614fc7cda973bb0fcc337a64021487e7c2c453d64e21a9ce635a4b04c0d605b",
      "configs\\wind_feature_sensitivity.json": "5918fd36c4708165ea1114074ffa1010ac17994c5cc0a718334010984401fd17",
      "scripts\\audit_data.py": "5ce1476c4334ae11c2927d3783a1d233fdbc7dc14c0239bfbbb0c89f84eba9e8",
      "scripts\\benchmark_peak_export.py": "5fedb570eab97b25e1f21fcdfc5cc8aefbb6a3136414c18784d44fee5da7b2fc",
      "scripts\\execute_review.py": "3e760b3c8aaeb05ec075bfa22fb33d529fd11ac0f3e15484d47621ccc6b13eb3",
      "scripts\\package_peak_review.py": "5c42495c050a3b3e52127c9c47fad2d3ae3a52c584ea657abe239edfbcb25b37",
      "scripts\\package_review.py": "3534b78c5908b2e07ca438afc7a90efbecf1a09edc9a5d818f3dfcee097cc380",
      "scripts\\verify_peak_outputs.py": "56b10bc9dd48cc27077c69b0cd0885df1c800affd84c2c8293c453fee61f086a"
    }
  },
  "dependencies": {
    "numpy": "2.3.5",
    "pandas": "3.0.1",
    "pyarrow": "25.0.1",
    "numba": "0.68.0",
    "llvmlite": "0.50.0",
    "jdatetime": "6.1.0",
    "jalali-core": "1.0.0",
    "tzdata": "2026.4",
    "psutil": "7.2.2"
  }
}

```

## Final independent verification

60 tests passed (handoff/peak_tests.xml). Independent serialized-output readback reconciled all 513,921 bills, including 21,705 zero bills; maximum absolute bill discrepancy was 3.637978807091713e-12 source units. All 362,660 distinct input IDs occur once, all same-day CSV estimates match the daily table exactly, and 12,927 valid zeros are retained. Independent math.fsum over the fixed population confirmed the selected date and total exactly. Source fingerprints match the final run. See handoff/peak_final_verification.json for artifact SHA256 hashes and output sizes.

Final full run: 218.387142 seconds; peak RSS 1,507,880,960 bytes. Two full runs produced identical peak metrics. Optional review items remain deferred as recorded in the review-resolution log.
