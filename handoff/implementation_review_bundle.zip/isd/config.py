from dataclasses import dataclass, asdict
from pathlib import Path

@dataclass(frozen=True)
class Config:
    mode: str = 'provisional_cohort_isd'
    engine: str = 'scaled'
    alpha: float = 0.05
    n_lr_models: int = 10
    n_disagg_cycles: int = 10
    target_start: str = '2025-01-20'
    target_end_exclusive: str = '2025-03-21'
    timezone: str = 'Asia/Tehran'
    feature_preset: str = 'winter_hdd65_v1'
    endpoint_convention: str = 'inclusive'
    endpoint_confirmed: bool = False
    calendar_origin_confirmed: bool = False
    day_basis_confirmed: bool = False
    target_year_confirmed: bool = False
    target_jalali_year_candidate: int = 1403
    physical_zero_confirmed: bool = False
    export_unmodified_confirmed: bool = False
    consumption_unit: str = 'source_units_unknown'
    provider_variable_definition: str = 'instant'
    weather_adapter: str = 'point_linear_integral_v1'
    ordering_version: str = 'customer_start_end_bill_id_v1'
    coverage_policy: str = 'balanced_cohort_uniform_elsewhere_v1'
    zero_residual_policy: str = 'keep_current'
    residual_tolerance_policy: str = '64eps_length_max_scale_v1'
    reconciliation_atol: float = 1e-8
    reconciliation_rtol: float = 1e-10
    regression_rcond: float | None = None
    exposure_scaled: bool = True
    production: bool = False
    max_customers: int | None = 1000
    sample_scope: str = 'universe'
    sample_seed: str = 'isd_pilot_v1:'
    row_group_size: int = 100000
    ingestion_chunk_size: int = 100000
    memmap_threshold_mb: int = 256
    checkpoint: bool = True
    resume: bool = False
    def validate(self):
        if self.mode not in ('paper_reference','provisional_cohort_isd'): raise ValueError('Unknown mode')
        if self.engine not in ('reference','scaled'): raise ValueError('Unknown engine')
        if not 0 <= self.alpha <= 1: raise ValueError('alpha outside [0,1]')
        for x in (self.n_lr_models,self.n_disagg_cycles,self.row_group_size,self.ingestion_chunk_size):
            if isinstance(x,bool) or not isinstance(x,int) or x < 1: raise ValueError('Positive integer counts required')
        if self.ordering_version!='customer_start_end_bill_id_v1' or self.coverage_policy!='balanced_cohort_uniform_elsewhere_v1' or self.residual_tolerance_policy!='64eps_length_max_scale_v1': raise ValueError('Unregistered policy requires a separate adaptation')
        if self.regression_rcond is not None and not 0<=self.regression_rcond<1: raise ValueError('Invalid rcond')
        if self.endpoint_convention != 'inclusive': raise ValueError('Other endpoints require a separately audited adapter')
        if self.max_customers is not None and (not isinstance(self.max_customers,int) or self.max_customers<1): raise ValueError('Invalid customer limit')
        if self.sample_scope not in ('universe','cohort'): raise ValueError('Unknown sampling scope')
        if self.zero_residual_policy!='keep_current': raise ValueError('Unsupported zero residual policy')
        if self.production and (not all([self.target_year_confirmed,self.endpoint_confirmed,self.calendar_origin_confirmed,self.day_basis_confirmed,self.export_unmodified_confirmed]) or self.consumption_unit=='source_units_unknown'):
            raise ValueError('Production semantic gates unresolved; use provisional exploratory mode')
        if self.mode=='paper_reference' and self.feature_preset!='paper_section3_v1': raise ValueError('Reference mode requires the Section 3 example features')
        return self
    def as_dict(self): return asdict(self)
